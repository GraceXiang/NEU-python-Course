from distutils.core import setup

setup(
    name='HiCity',
    version='v0.8',
    py_modules=['HiCity.HiCity', 'HiCity.server']
)

